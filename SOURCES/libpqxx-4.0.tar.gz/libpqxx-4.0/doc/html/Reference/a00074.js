var a00074 =
[
    [ "~pqxx_exception", "a00074.html#a9386d73e8176de81de9b1fe38afa6952", null ],
    [ "base", "a00074.html#a27f927cf3a5f478abc29337d02767144", null ]
];