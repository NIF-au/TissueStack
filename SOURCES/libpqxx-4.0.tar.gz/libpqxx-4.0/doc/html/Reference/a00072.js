var a00072 =
[
    [ "plpgsql_too_many_rows", "a00072.html#a8b2c0fa01d76add8d15f1024562521fe", null ],
    [ "plpgsql_too_many_rows", "a00072.html#a77fc4dece10e4aa3efffc7f4dcbeb81e", null ]
];