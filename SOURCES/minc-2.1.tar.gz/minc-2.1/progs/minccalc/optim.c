#include "node.h"

node_t optimize(node_t root){
   return root;
}
