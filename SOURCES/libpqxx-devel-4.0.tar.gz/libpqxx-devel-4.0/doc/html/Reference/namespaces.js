var namespaces =
[
    [ "pqxx", "a00176.html", null ]
];