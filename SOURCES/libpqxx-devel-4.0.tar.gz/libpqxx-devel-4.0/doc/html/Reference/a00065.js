var a00065 =
[
    [ "max", "a00065.html#ae5fc707d9d6ebbac808a5fb6e26690f8", null ],
    [ "max", "a00065.html#af71385909ae48a64f6e88d19f940bcd1", null ],
    [ "min", "a00065.html#a672ff8f843f277b741fef22594a1d78f", null ],
    [ "min", "a00065.html#a9387cf870c1b7d0f6ced0db05614e494", null ]
];