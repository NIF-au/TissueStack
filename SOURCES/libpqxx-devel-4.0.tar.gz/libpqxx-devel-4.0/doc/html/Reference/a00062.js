var a00062 =
[
    [ "notification_receiver", "a00062.html#af1f7329b7989d05272f6ac354fa1ac3e", null ],
    [ "~notification_receiver", "a00062.html#ae4ed572d3a137b331d363bae82f4ce9b", null ],
    [ "channel", "a00062.html#a8c675af7630284e6b919a8523595d1d7", null ],
    [ "conn", "a00062.html#a972d65eb33a24b044e9d5c2cb342cd14", null ],
    [ "operator()", "a00062.html#ab1956501c582e41377bc54b4db377ded", null ]
];