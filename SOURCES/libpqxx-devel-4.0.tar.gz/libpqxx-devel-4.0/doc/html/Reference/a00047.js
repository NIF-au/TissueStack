var a00047 =
[
    [ "insufficient_resources", "a00047.html#ab9c012d8591a9699677c8e3d2bfdf02a", null ],
    [ "insufficient_resources", "a00047.html#af88552eb661d1bc459308d2ff8576840", null ]
];