var a00042 =
[
    [ "foreign_key_violation", "a00042.html#a6e1d093886e976b8e028d94daba4c16e", null ],
    [ "foreign_key_violation", "a00042.html#a63de30ac68704846bbe21c078d23be53", null ]
];