var a00021 =
[
    [ "connect_lazy", "a00021.html#a9d93b15b0681f3b4e25e9fab79adb8cd", null ],
    [ "do_completeconnect", "a00021.html#ad5c2b3b6043ff998ad67cddc89e2669b", null ]
];