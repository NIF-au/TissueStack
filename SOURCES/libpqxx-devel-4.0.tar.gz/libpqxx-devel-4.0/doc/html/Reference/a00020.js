var a00020 =
[
    [ "connect_direct", "a00020.html#a3ae8ab240a1f152c64cd40493d92f846", null ],
    [ "do_startconnect", "a00020.html#a2b3538872ddbadb1e1a4aadc7724afb6", null ]
];