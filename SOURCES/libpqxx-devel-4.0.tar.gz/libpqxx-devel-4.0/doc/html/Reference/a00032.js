var a00032 =
[
    [ "~dbtransaction", "a00032.html#ace1dc32cc5ab0d51481518e659675b79", null ],
    [ "dbtransaction", "a00032.html#a49d5c0050ec02eba8440b1bdb20a1539", null ],
    [ "dbtransaction", "a00032.html#a12e833c152ed73fabe7c4c30020140e2", null ],
    [ "do_abort", "a00032.html#a38c5eb7ae19ad150f89e951261873aba", null ],
    [ "do_begin", "a00032.html#a0b4da4b562a51ec0f03a9abf75acd14c", null ],
    [ "do_commit", "a00032.html#ae434c2ec625a55ec8c6c4f57d1cb0a54", null ],
    [ "do_exec", "a00032.html#a9b3e988901d4bec05d414543314a945b", null ],
    [ "fullname", "a00032.html#a4e35ec39c80f088ebe239b15a16488de", null ],
    [ "start_backend_transaction", "a00032.html#a601f599d9c5cca86ce84a77bdac941db", null ]
];