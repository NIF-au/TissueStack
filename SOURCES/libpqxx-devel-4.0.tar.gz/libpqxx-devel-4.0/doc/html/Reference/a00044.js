var a00044 =
[
    [ "difference_type", "a00044.html#a79c9e623be28567215d88087cd7e80d0", null ],
    [ "size_type", "a00044.html#a6f29a9a658eeb39c09075bfc655c5d90", null ],
    [ "icursorstream", "a00044.html#a9d23e2f3cdac465efb354e0ab689304c", null ],
    [ "icursorstream", "a00044.html#a24212e9d6d97c744f5c4eed30d8d92a2", null ],
    [ "get", "a00044.html#a0602dd0f6ed2641bbb98ad584bcf60e7", null ],
    [ "ignore", "a00044.html#a777b5c8fe3f9e0160cea11ba00be5a27", null ],
    [ "operator bool", "a00044.html#a462bf00fed476b503116f1c769deeb2f", null ],
    [ "operator>>", "a00044.html#a7ac105c3e882661d8f1220ccf9164c27", null ],
    [ "set_stride", "a00044.html#a255914b05d1f935922338eeebcb10144", null ],
    [ "stride", "a00044.html#a89f9c7dc295e4befa9bdbd2bfedbe800", null ],
    [ "internal::gate::icursorstream_icursor_iterator", "a00044.html#a81bc68e9ddb56368929d58e0820e72f0", null ]
];