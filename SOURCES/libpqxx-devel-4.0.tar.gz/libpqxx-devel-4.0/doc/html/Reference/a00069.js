var a00069 =
[
    [ "plpgsql_error", "a00069.html#abb0f0e6d4eaebe63d7409c244ffa9b06", null ],
    [ "plpgsql_error", "a00069.html#a346ab5182768a7a9b25c03e45890c601", null ]
];