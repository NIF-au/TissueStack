var a00206 =
[
    [ "errorhandler", "a00036.html", null ],
    [ "quiet_errorhandler", "a00076.html", null ]
];